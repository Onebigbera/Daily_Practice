create trigger generate_perchas_bak
  after INSERT
  on tb_perchas
  for each row
  begin
insert into perchas_bak(id,name,num)values(new.id,new.name,new.num);
end;

